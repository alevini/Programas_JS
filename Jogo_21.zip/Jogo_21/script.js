"use strict";

let player1_pontos = document.querySelector(".player1-pontos");
let player2_pontos = document.querySelector(".player2-pontos");

const player1_rodada = document.querySelector(".rodada-p1");
const player2_rodada = document.querySelector(".rodada-p2");

const carta = document.querySelector(".carta");

const btn_comprar = document.querySelector(".btn-comprar-carta");
const btn_parar = document.querySelector(".btn-parar");
const btn_comoJogar = document.querySelector(".btn-comoJogar");
const btn_fechar = document.querySelector(".btn-fechar");

let pontos_p1 = 0;
let pontos_p2 = 0;
let rodada_p1 = 0;
let rodada_p2 = 0;

let player_atual = 0;

let isOverflowP1 = false;
let isOverflowP2 = false;

function Init() {
  player1_pontos.textContent = pontos_p1;
  player2_pontos.textContent = pontos_p2;
  player1_rodada.textContent = rodada_p1;
  player2_rodada.textContent = rodada_p2;
  carta.classList.add("hidden");

  document.querySelector(".player-1").classList.add("atual");
}

function Comprar_Carta() {
  const dice = Math.trunc(Math.random() * 10) + 1;
  const naipe = Math.trunc(Math.random() * 4) + 1;

  carta.classList.remove("hidden");

  if (naipe === 1) {
    carta.src = `img/Copas/carta-${dice}.png`;
  } else if (naipe === 2) {
    carta.src = `img/espada/carta-${dice}.png`;
  } else if (naipe === 3) {
    carta.src = `img/ouro/carta-${dice}.png`;
  } else if (naipe === 4) {
    carta.src = `img/paus/carta-${dice}.png`;
  }

  // carta.src = `img/ace-${dice}.png`;
  console.log(carta.src);

  if (document.querySelector(".player-1").classList.contains("atual")) {
    pontos_p1 += dice;
    player1_pontos.textContent = pontos_p1;
    Verificar_Overflow();
  } else {
    pontos_p2 += dice;
    player2_pontos.textContent = pontos_p2;
    Verificar_Overflow();
  }
}

function Mudar_Jogador_Atual() {
  if (document.querySelector(".player-1").classList.contains("atual")) {
    document.querySelector(".player-1").classList.remove("atual");
    document.querySelector(".player-2").classList.add("atual");
  } else {
    document.querySelector(".player-1").classList.add("atual");
    document.querySelector(".player-2").classList.remove("atual");
  }
}

function Verificar_Overflow() {
  if (document.querySelector(".player-1").classList.contains("atual")) {
    if (pontos_p1 > 21) {
      isOverflowP1 = true;
      pontos_p1 = 0;
      Mudar_Jogador_Atual();
    }
  } else if (document.querySelector(".player-2").classList.contains("atual")) {
    if (pontos_p2 > 21) {
      isOverflowP2 = true;
      Mudar_Rodada();
    }
  }
}

function Mudar_Rodada() {
  //verificar quem venceu e atribuir o ponto pra ele
  Quem_Venceu_Rodada();
  //zerar os pontos visualmente e nas var
  Zerar_Rodada();

  Mudar_Jogador_Atual();
}

function Zerar_Rodada() {
  player1_pontos.textContent = 0;
  pontos_p1 = 0;
  isOverflowP1 = false;

  player2_pontos.textContent = 0;
  pontos_p2 = 0;
  isOverflowP2 = false;
}

//SÓ É CHAMADA NO JOGADOR 2 e PARAR DE COMPRAR
//por isso pode zerar a rodada
function Quem_Venceu_Rodada() {
  if (isOverflowP1 && isOverflowP2) {
    //se ambos estourarem .. joga de novo
    return;
  } else if (pontos_p1 === pontos_p2) {
    Zerar_Rodada();
  } else if (pontos_p1 > pontos_p2 || isOverflowP2) {
    rodada_p1++;
    player1_rodada.textContent = rodada_p1;
    Zerar_Rodada();
  } else if (pontos_p2 > pontos_p1) {
    rodada_p2++;
    player2_rodada.textContent = rodada_p2;
    Zerar_Rodada();
  }
}

function Parar_de_Comprar() {
  if (document.querySelector(".player-1").classList.contains("atual")) {
    document.querySelector(".player-1").classList.remove("atual");
    document.querySelector(".player-2").classList.add("atual");
  } else {
    document.querySelector(".player-1").classList.add("atual");
    document.querySelector(".player-2").classList.remove("atual");
    Quem_Venceu_Rodada();
    Gameover();
  }
}

function Gameover() {
  if (rodada_p1 === 5) {
    //desabilitar os botoes
    btn_comprar.removeEventListener("click", Comprar_Carta);
    btn_parar.removeEventListener("click", Parar_de_Comprar);

    //esconder a carta
    carta.classList.add("hidden");

    //mudar background
    document.querySelector(".player-1").classList.remove("atual");
    document.querySelector(".player-2").classList.remove("atual");

    document.querySelector(".player-1").classList.add("gameover");
  } else if (rodada_p2 === 5) {
    //desabilitar os botoes
    btn_comprar.removeEventListener("click", Comprar_Carta);
    btn_parar.removeEventListener("click", Parar_de_Comprar);

    //esconder a carta
    carta.classList.add("hidden");

    //mudar background
    document.querySelector(".player-1").classList.remove("atual");
    document.querySelector(".player-2").classList.remove("atual");

    document.querySelector(".player-2").classList.add("gameover");
  } else {
    return;
  }
}

function Como_Jogar() {
  document.querySelector(".modal").classList.remove("hidden");
}

function Fechar_Modal() {
  document.querySelector(".modal").classList.add("hidden");
}

Init();
btn_comprar.addEventListener("click", Comprar_Carta);
btn_parar.addEventListener("click", Parar_de_Comprar);
btn_comoJogar.addEventListener("click", Como_Jogar);
btn_fechar.addEventListener("click", Fechar_Modal);
